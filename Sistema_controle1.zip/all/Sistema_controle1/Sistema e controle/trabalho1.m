ref = 80;
 
tau1 = 0.8;  
tau2 = 5*(1+(ref-30)/50);
wn = 2*(1-ref/200);
zeta = 0.5*(1-ref/400);
sat1 =500;  
atraso = tau2/4; 
p1 = 4.5;      
Temp = 100;
sim('processo3');  
saida='Temperatura';
t = Y(:,1);           
u = Y(:,2);
y = Y(:,3);         
plot(t,u,t,y)
xlabel('tempo(s)')
ylabel(saida)
legend('u','y')
shg

