clc
clear all
close all

s = tf('s')
G = 3.77 /(0.71*s + )
figure
step(G)

