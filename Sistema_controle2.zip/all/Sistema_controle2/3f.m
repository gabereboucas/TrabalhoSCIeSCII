  g = tf([1 0 -9],[1 12 32 0])

g =
 
        s^2 - 9
  -------------------
  s^3 + 12 s^2 + 32 s
 
Continuous-time transfer function.

rlocus(g)
