g = tf([1 -8 15],[1 6 8 0])
rlocus(g)
sisotool(g)
[r,p] = rlocus(g)
