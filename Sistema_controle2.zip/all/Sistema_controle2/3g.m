g = tf([1 6],[1 6 8 0])

g =
 
        s + 6
  -----------------
  s^3 + 6 s^2 + 8 s
 
Continuous-time transfer function.

rlocus(g)